var searchData=
[
  ['tile',['Tile',['../class_tile.html#aeeb5593bb6b75aae2edfcccbc84ab378',1,'Tile::Tile()'],['../class_tile.html#a1ddd4b0d2f92069d70bd3742ce669f2a',1,'Tile::Tile(int ID)']]]
];
