var searchData=
[
  ['id',['ID',['../class_player.html#af3a95513ac314d13a7130ac12221420e',1,'Player::ID()'],['../class_tile.html#a5beb521b18c3729b76f820e6a8aff24c',1,'Tile::ID()']]]
];
