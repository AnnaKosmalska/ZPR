var searchData=
[
  ['removepair',['removePair',['../class_board.html#ad7c95a1832eec6803fd227897549902b',1,'Board']]]
];
