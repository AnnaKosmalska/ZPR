var _board_8hpp =
[
    [ "addPlayer", "_board_8hpp.html#aa0e23ac2c6eaca5750c2ce0cdfd8171e", null ],
    [ "BOOST_PYTHON_MODULE", "_board_8hpp.html#a0b905b9fdb71bd3df7f921e6c2e57a49", null ],
    [ "choose", "_board_8hpp.html#a422d7f5663a31e34a66e1c9f35ae5ce1", null ],
    [ "endGame", "_board_8hpp.html#aeda119595fcc834db9cfec532a90cf79", null ],
    [ "endTurn", "_board_8hpp.html#ab937b9d10762b7e6bb1e9650b7e39c72", null ],
    [ "getCurrentPlayer", "_board_8hpp.html#aa61840df094e7aa5809ff8342ebde6e6", null ],
    [ "getFirstPicked", "_board_8hpp.html#a77dbb2f896aa46fe813c8909d01d0dac", null ],
    [ "getFirstX", "_board_8hpp.html#a1a870f0a6101aa08346d9cebffdb2c8e", null ],
    [ "getFirstY", "_board_8hpp.html#a45508b0afeef3e221ef980611ea1a197", null ],
    [ "getScore", "_board_8hpp.html#a8f1a85d860b657664aa17217af1b1191", null ],
    [ "getSecondPicked", "_board_8hpp.html#a07302bfdbfd155e5692e034e1ebd438e", null ],
    [ "getSecondX", "_board_8hpp.html#a3d23e6c1ef79f6d553675c6b1e6f94c2", null ],
    [ "getSecondY", "_board_8hpp.html#aef017f2c117568a607d032e28cd38d72", null ],
    [ "getState", "_board_8hpp.html#a0452e3b31c7042df8512153a62eff5d8", null ],
    [ "initGame", "_board_8hpp.html#abd18a3e4e5962e6d19f2d22fa77ec616", null ]
];