var hierarchy =
[
    [ "BaseException", "class_base_exception.html", [
      [ "GameInProgressException", "class_game_in_progress_exception.html", null ],
      [ "GameNotStartedException", "class_game_not_started_exception.html", null ],
      [ "MaxPlayersException", "class_max_players_exception.html", null ],
      [ "NoPlayerException", "class_no_player_exception.html", null ],
      [ "NotCurrentPlayerException", "class_not_current_player_exception.html", null ],
      [ "TileOutOfBoardException", "class_tile_out_of_board_exception.html", null ],
      [ "TwoTilesChosenException", "class_two_tiles_chosen_exception.html", null ],
      [ "UknownPlayerException", "class_uknown_player_exception.html", null ],
      [ "WrongParametersException", "class_wrong_parameters_exception.html", null ]
    ] ],
    [ "Board", "class_board.html", null ],
    [ "Deck", "class_deck.html", null ],
    [ "Player", "class_player.html", null ],
    [ "Tile", "class_tile.html", null ]
];