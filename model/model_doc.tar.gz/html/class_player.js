var class_player =
[
    [ "Player", "class_player.html#a6e3242b7488f410597bdf7bb5a0ebaeb", null ],
    [ "~Player", "class_player.html#a749d2c00e1fe0f5c2746f7505a58c062", null ],
    [ "addToDeck", "class_player.html#a8b5afa75dc64adefa464ea8dc3affa85", null ],
    [ "getDeck", "class_player.html#a565a270f3c6d0e61414c17edfc8c9e62", null ],
    [ "getID", "class_player.html#a7fe06822d03f93cff83cd17894df986b", null ],
    [ "getName", "class_player.html#af1aa472885d589516f483e26e786600e", null ],
    [ "getScore", "class_player.html#ac10eb9fb0387f565134958d129585ac6", null ],
    [ "incScore", "class_player.html#a4277b929f0d0c50722a7ab8d7dbbdf4e", null ],
    [ "deck", "class_player.html#aec166255eeaa878ab56f5b66fe726939", null ],
    [ "ID", "class_player.html#af3a95513ac314d13a7130ac12221420e", null ],
    [ "name", "class_player.html#af9c920fabaafdeb7961a645315b521ff", null ],
    [ "score", "class_player.html#ace6abae8d66534ad0a1fd6458f786a6e", null ]
];