var searchData=
[
  ['name',['name',['../class_player.html#af9c920fabaafdeb7961a645315b521ff',1,'Player']]],
  ['noplayerexception',['NoPlayerException',['../class_no_player_exception.html',1,'']]],
  ['notcurrentplayerexception',['NotCurrentPlayerException',['../class_not_current_player_exception.html',1,'']]]
];
