var searchData=
[
  ['firstpicked',['firstPicked',['../class_board.html#a568e0d05bc753b54bf816ecd5c74b061',1,'Board']]],
  ['firstx',['firstX',['../class_board.html#a290241ae21e193e56f7180ea7ef3898b',1,'Board']]],
  ['firsty',['firstY',['../class_board.html#a575553c1c74ab20d8c0c1f098f420833',1,'Board']]]
];
