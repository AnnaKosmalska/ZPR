var searchData=
[
  ['players',['players',['../class_board.html#a886a8cf50ba8c37a7d5bfbea318ef3ae',1,'Board']]]
];
