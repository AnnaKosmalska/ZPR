var class_deck =
[
    [ "Deck", "class_deck.html#a57ae1cb4ac6fd61c249cefb2db85eb99", null ],
    [ "~Deck", "class_deck.html#a7d1331cc558c302fdf44e5ae8aae1a95", null ],
    [ "addTile", "class_deck.html#a7fc05d25d0348a62ee906dabc07c9bb5", null ],
    [ "getNumber", "class_deck.html#ab1f5ee1aff969d5cc897f5da4acdf06c", null ],
    [ "getTiles", "class_deck.html#ab1d1f2f1a4f329b9041df685232d8faf", null ],
    [ "deck", "class_deck.html#a40fde12d23974b43a5f83ee4f57f0f6f", null ]
];