var searchData=
[
  ['score',['score',['../class_player.html#ace6abae8d66534ad0a1fd6458f786a6e',1,'Player']]],
  ['secondpicked',['secondPicked',['../class_board.html#ad8c2bf7725fb0ec21c4f87b964766d9b',1,'Board']]],
  ['secondx',['secondX',['../class_board.html#ab7dc900f0608bb07d5ce64b7991eba8b',1,'Board']]],
  ['secondy',['secondY',['../class_board.html#a39548b2fb38e161a1160100cf3e8ecb8',1,'Board']]],
  ['sizex',['sizeX',['../class_board.html#aee950abc74fe0e8b27d4cad6e683b48c',1,'Board']]],
  ['sizey',['sizeY',['../class_board.html#a7be047ee9838187887f9afd5178a0744',1,'Board']]],
  ['state',['state',['../class_board.html#abcbd83a5c17c56ed6246a53a0c92169d',1,'Board']]]
];
