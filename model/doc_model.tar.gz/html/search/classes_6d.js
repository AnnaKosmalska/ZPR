var searchData=
[
  ['maxplayersexception',['MaxPlayersException',['../class_max_players_exception.html',1,'']]]
];
