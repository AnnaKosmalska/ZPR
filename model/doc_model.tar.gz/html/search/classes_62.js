var searchData=
[
  ['baseexception',['BaseException',['../class_base_exception.html',1,'']]],
  ['board',['Board',['../class_board.html',1,'']]]
];
