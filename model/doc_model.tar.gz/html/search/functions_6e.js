var searchData=
[
  ['nextplayer',['nextPlayer',['../class_board.html#aabd3b53f9106ebc63855bdc08d2f5b81',1,'Board']]]
];
