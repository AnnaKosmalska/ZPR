var class_tile =
[
    [ "Tile", "class_tile.html#aeeb5593bb6b75aae2edfcccbc84ab378", null ],
    [ "Tile", "class_tile.html#a1ddd4b0d2f92069d70bd3742ce669f2a", null ],
    [ "~Tile", "class_tile.html#a98634abbd93fa13d0578d7103202d03d", null ],
    [ "getID", "class_tile.html#a174bc8a5b1e962525783c057fbbc5ea1", null ],
    [ "operator==", "class_tile.html#a872d3b7acf34b71b80c9111bc97a5c9d", null ],
    [ "ID", "class_tile.html#a5beb521b18c3729b76f820e6a8aff24c", null ]
];