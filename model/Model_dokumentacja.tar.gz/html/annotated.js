var annotated =
[
    [ "Board", "class_board.html", "class_board" ],
    [ "Deck", "class_deck.html", "class_deck" ],
    [ "Player", "class_player.html", "class_player" ],
    [ "Tile", "class_tile.html", "class_tile" ]
];