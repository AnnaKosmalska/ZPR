var searchData=
[
  ['player',['Player',['../class_player.html',1,'Player'],['../class_player.html#a6e3242b7488f410597bdf7bb5a0ebaeb',1,'Player::Player()']]],
  ['player_2ecpp',['Player.cpp',['../_player_8cpp.html',1,'']]],
  ['player_2ehpp',['Player.hpp',['../_player_8hpp.html',1,'']]],
  ['players',['players',['../class_board.html#a886a8cf50ba8c37a7d5bfbea318ef3ae',1,'Board']]],
  ['playersnumber',['playersNumber',['../class_board.html#af1fc4b2c5250114a51fb0e974026c62e',1,'Board']]]
];
