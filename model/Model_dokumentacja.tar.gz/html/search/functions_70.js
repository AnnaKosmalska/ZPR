var searchData=
[
  ['player',['Player',['../class_player.html#a6e3242b7488f410597bdf7bb5a0ebaeb',1,'Player']]],
  ['playersnumber',['playersNumber',['../class_board.html#af1fc4b2c5250114a51fb0e974026c62e',1,'Board']]]
];
