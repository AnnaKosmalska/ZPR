var searchData=
[
  ['endgame',['endGame',['../class_board.html#a84af5ad82d600417fb03cf3988775ec5',1,'Board::endGame()'],['../_board_8hpp.html#aeda119595fcc834db9cfec532a90cf79',1,'endGame():&#160;Board.hpp']]],
  ['endturn',['endTurn',['../class_board.html#ab3413f7cbad9d1c5993602f7d4161b05',1,'Board::endTurn()'],['../_board_8hpp.html#ab937b9d10762b7e6bb1e9650b7e39c72',1,'endTurn():&#160;Board.hpp']]]
];
