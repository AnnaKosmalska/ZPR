var searchData=
[
  ['name',['name',['../class_player.html#af9c920fabaafdeb7961a645315b521ff',1,'Player']]]
];
