var searchData=
[
  ['all',['all',['../class_board.html#ac744937ccabf38fbb6a769692a1a11e8',1,'Board']]]
];
