var searchData=
[
  ['board',['board',['../class_board.html#a38318427833eef0c82498b0f5bcc7651',1,'Board']]]
];
