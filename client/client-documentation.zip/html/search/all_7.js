var searchData=
[
  ['opentiles',['openTiles',['../test07_8html.html#a94530a28774856e37894e8e8b6436ead',1,'test07.html']]],
  ['opentilescount',['openTilesCount',['../test07_8html.html#a9173fa1db31ab6e028de1977d149e4be',1,'test07.html']]]
];
