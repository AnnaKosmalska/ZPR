var searchData=
[
  ['xhr',['xhr',['../jquery-1_811_80_8js.html#a0b7a5cb538ca9913b1b3b1c807ad06f0',1,'jquery-1.11.0.js']]],
  ['xhrcallbacks',['xhrCallbacks',['../jquery-1_811_80_8js.html#a068f27a70831ff3a9e0ffa79e063847f',1,'jquery-1.11.0.js']]],
  ['xhrid',['xhrId',['../jquery-1_811_80_8js.html#aa23ed64cf7afc9b028419517bf23fcea',1,'jquery-1.11.0.js']]],
  ['xhrsupported',['xhrSupported',['../jquery-1_811_80_8js.html#afd7e72f2f357a5a8b17e46776a6283eb',1,'jquery-1.11.0.js']]]
];
