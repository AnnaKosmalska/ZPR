var searchData=
[
  ['checkstate',['checkState',['../test07_8html.html#a6b6ed7853ca33704b92d3dcc91d26af6',1,'test07.html']]],
  ['checktile',['checkTile',['../test07_8html.html#a2dffadefbec63a815a7c006a7ba34d73',1,'test07.html']]],
  ['closetiles',['closeTiles',['../test07_8html.html#aa4ec43935a1ad846a3085668cfa1d3f5',1,'test07.html']]]
];
