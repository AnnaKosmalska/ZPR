var searchData=
[
  ['picturesopen',['picturesOpen',['../test07_8html.html#a94efafeedde18477c2866924ece3d07f',1,'test07.html']]]
];
